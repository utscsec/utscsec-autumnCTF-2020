const { join } = require('path')
const pug = require('pug')
const jwt = require('jsonwebtoken')
const pointOfView = require('point-of-view')
const fastifyStatic = require('fastify-static')
const fastifyFormBody = require('fastify-formbody')
const path = require("path")
const expectedUsername = process.env.USERNAME || 'testusername'
const expectedPassword = process.env.PASSWORD || 'atestpassword1@3$'

var fs = require('fs')

var privatekey = fs.readFileSync(path.resolve(__dirname, 'jwtRS256.key'))
console.log('PRIVATE KEY IS ' + privatekey)
var publickey = fs.readFileSync(path.resolve(__dirname, 'jwtRS256.key.pub'))
console.log('PUBLIC KEY IS ' + publickey)
module.exports = (fastify, opts, next) => {
	fastify.register(fastifyFormBody)
  	fastify.register(pointOfView, {
    		engine: {pug},
    		templates: join(__dirname, 'templates'),
    		options: {
      		pretty: true,
      		filename: 'Pug',
      		basedir: join(__dirname, 'templates')
    		}
  	})
	fastify.register(fastifyStatic, {
		root: join(__dirname, 'assets'),
		prefix: '/assets/'
	})

	fastify.get('/', (req, reply) => {
		var authtoken = ''
		if (req.headers['cookie']) {
        		if (req.headers['cookie'].includes("Auth")) {
    	    			authtoken = req.headers['cookie'].split('Auth')[1].trim().split('=')[1].trim().split(';')[0]
        		}
		} 
		console.log(authtoken)
		let error = false
		let session = null
		const sid = authtoken
		if (sid) {
      			try {
        			session = jwt.verify(sid, publickey, {algorithms:['HS256', 'RS256']}) //Vulnerable line, if users say a token signed by HMAC in jwt head then app will use the public key as the secret, users can sign tokens
      			} catch (err) {
        			error = 'Invalid session token'
      			}
    		}

		reply.view('index.pug', {session, error})
	})

	fastify.get('/login', (req, reply) => {
		reply.view('login.pug', {hasError: req.query.error})
	})

	fastify.post('/login', (req, reply) => {
		const {username, password} = req.body
		if (
			username !== expectedUsername ||
			password !== expectedPassword
		) {
			return reply.redirect('/login?error=1')
    		}
//		creates a jwt signed using RS256 signed by the private key
		const jwtToken = jwt.sign({ sub: username, role: 'user' }, privatekey, { algorithm: 'RS256' })  
//		console.log(jwt.sign({sub: username, role: 'user'}, publickey) + "  |  A TEST TOKEN")
//		console.log('THIS TOKEN WAS SIGNED WITH THE VALUE\n' + privatekey)
//		console.log('THE CORRESPONDING PUBLIC KEY IS\n' + publickey)

		// redirect with parameter
		reply.headers({'Set-Cookie':'Auth=' + jwtToken})
		return reply.redirect(`/`)
	})
	fastify.get('/key.pem', (req, reply) => {
		reply.send(publickey)
	})
	//A very janky method of serving up a 'robots.txt' page because I have no idea how to make fastify send files
	fastify.get('/robots.txt', (req, reply) => {
		reply.send('User-aget:*\nDisallow: /key.pem')
	})
	next()
}
